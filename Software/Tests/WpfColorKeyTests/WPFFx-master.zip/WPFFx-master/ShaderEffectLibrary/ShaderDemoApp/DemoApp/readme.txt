﻿
To add new Effects to the test application. 
1.- Add a new data template in TemplatesToConfigureEffects.xaml 
2.- Add an entry in the to EffectsList.All  in ViewModel.cs 


To add new Content types: 
1.- Add a new template in ContentTemplates.xaml 
2.- Add an entry in the to ContentList.All  in ViewModel.cs 

