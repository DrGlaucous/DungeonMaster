﻿These images are included in the .Web site.. 

It needs to be at least 10 images, named 0.jpg, 1.jpg, 2.jpg, through 9.jpg, etc.. 