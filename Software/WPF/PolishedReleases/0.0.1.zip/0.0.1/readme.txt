==Program version: 0.0.1==


This folder represents the layout the data will be with the final program. All TSC that needs to access media should do so with this format in mind.








