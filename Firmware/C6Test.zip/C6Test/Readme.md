### About

This project folder is a very quick and dirty test to get the ESP32-c6 devkit set up and working with platformIO and the arduino framework.

Because the c6 is so new, the arduino framework for it has not been mainstreamed into the platformIO environment yet, but Jason2866 created a bleeding-edge implementation of the arduino framework so we can use it with the c6 early. This project tests this and nothing more.



